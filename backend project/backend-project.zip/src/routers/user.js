let express = require("express")
const session = require('express-session');
const cookie_parser = require('cookie-parser');

let router = express.Router()

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const SECRET_KEY = "NOTESAPI"

let document = require("../models/schema")
let sliderdoc = require("../models/slider")
let services = require("../models/service")
let feedbackdoc = require("../models/feedback")
let registerdoc = require("../models/register")
let achdoc = require("../models/achievement")
let bookappodoc = require("../models/book-app")



router.use(cookie_parser())
router.use(session({
  secret: 'SECRET_KEY',
  resave: false,
  saveUninitialized: true,

}));


function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    // User is authenticated, call the next middleware function
    return next();
  } else {
    // User is not authenticated, redirect to the login page
    res.redirect('/login');
  }
}




//process contactus form
router.use(express.json())


//creating register page
router.get('/', (req, res) => {
  res.render("register");

});


//check register
router.post("/", async (req, res) => {
  const { username, email, password } = req.body
  //above line is short cut for getting usernam,email,password from register form in one line
  //console.log(username,email,password)
  try {
    //check existing user
    const existuser = await registerdoc.find({ email: email })
    // console.log(existuser)
    if (existuser.length > 0) {
      return res.status(400).json({ message: "user already exist" })
    }
    //hasing the password (10 called salt)
    const hashedpassword = await bcrypt.hash(password, 10)
    //user creating
    const createentry = new registerdoc({
      email: email,
      username: username,
      password: hashedpassword,
      
    })
    await createentry.save()
    //create token
    const token = jwt.sign({ email: createentry.email, id: createentry._id }, SECRET_KEY)
    res.status(200).redirect("/login")
  }
  catch (err) {
    console.log(err)
    res.status(200).redirect("/")
    res.status(500).json({ message: "somenthing went wrong" })
  }
})




//creating login page
router.get('/login', (req, res) => {
  res.render("login");

});




//check login
router.post("/login", async (req, res) => {
  req.session.user = req.body
  req.session.save()
  const { username, password } = req.body
  // console.log(username,password)
  try {
    //check existing user
    const existuser = await registerdoc.find({ username: username })
    let email = existuser[0].email
    //console.log(email)  
    req.session.user = email;
    req.session.save()
    if (existuser.length == 0) {
      return res.status(404).json({ message: "user not found" })
    }
    const matchpassword = await bcrypt.compare(password, existuser[0].password)
    if (!matchpassword) {
      return res.status(400).json({ message: "wrong password" })
    }

    const token = jwt.sign({ email: existuser.email, id: existuser._id }, SECRET_KEY)
    res.status(200).redirect("/home")

  }
  catch (err) {
    console.log(err)
    res.status(500).json({ message: "somenthing went wrong" })
  }
})




//logout
router.get("/home/logout", (req, res) => {
  // Clear the session cookie to log the user out
   res.clearCookie('session')
  req.session.destroy()
  // console.log("user loged out")
  // Redirect to the login page or any other page you want to redirect after logout
  res.redirect('/login');
});




//creating home page
router.get("/home", isAuthenticated, async (req, res) => {
  try {
    let navbar = await document.find({ "_id": "6425912e18d06441716f6ddf" })
    //console.log(navbar[0].logo)
    let sliderdata = await sliderdoc.find();
    // console.log(sliderdata)
    let servicedata = await services.find();

    res.render("index", { data: navbar, sliderdata: sliderdata, servicedata: servicedata })
  }
  catch (err) { console.log(err) }
})




//create acheviments
router.get("/home/achievements", isAuthenticated, async (req, res) => {
  try {
    let navbar = await document.find({ "_id": "6425912e18d06441716f6ddf" })
    //console.log(navbar[0].logo)
    let achdata = await achdoc.find()

    res.render("achievements", { data: navbar, achdata: achdata })
  }
  catch (err) { console.log(err) }
})



//feed back
router.post("/usersubmit", isAuthenticated, async (req, res) => {
  let email = req.body.email
  let phone = req.body.phone
  let fb = req.body.feedback
  //console.log(email,query,phone)
  try {
    let feedbackentry = new feedbackdoc({
      email: email,
      phone: phone,
      feedback: fb
    })
    await feedbackentry.save()
    res.status(200).redirect("/home")
  }
  catch (e) {
    console.log(e.message)
    res.status(500).redirect("/home")
  }
})




//get appointment form 
router.get("/make-appointments", isAuthenticated, async(req, res) => {
  let sessionemail = req.session.user
  res.render("makeAppo", { email: sessionemail})
})



//post appointmentdata 
router.post("/make-appointments", isAuthenticated, async (req, res) => {
  let { firstname, lastname, email, phonenumber, date, time, address, city, state,service } = req.body
  //console.log(phonenumber, date, time)
  
  try {
    const bookentry = new bookappodoc({
      email: email,
      firstname: firstname,
      lastname: lastname,
      phone: phonenumber,
      appointmentDate: date,
      appointmentTime: time,
      address: address,
      city: city,
      state: state,
      service:service
    })
    
    const existingdata = await bookappodoc.find({ appointmentDate:date});
     let c=[]
    for(let ele of existingdata){
      c.push(ele.appointmentTime)
    }
    // console.log(c)
     const existingTimeSlot = await bookappodoc.findOne({ appointmentDate:date, appointmentTime:time });
     if (existingTimeSlot) {
     res.status(400).json({message:`Time${date,time} slot already booked.......and 
      ${c} The slots for the selected date have already been booked. Please go back and select another available slot.`});    
   }
  
    else{
    await bookentry.save()
    res.status(200).redirect("/home/our-appointments")
    }
  }
 catch (err) {
    console.log(err)
    res.status(200).redirect("/")
    res.status(500).json({ message: "somenthing went wrong" })
  }
})




//get our appointments
router.get("/home/our-appointments", isAuthenticated, async (req, res) => {
  try {
    let navbar = await document.find({ "_id": "6425912e18d06441716f6ddf" })
    //console.log(req.session.user)
    let sessionemail = req.session.user
    let appodata = await bookappodoc.find({ email: sessionemail })
    // console.log(appodata)

    res.render("ourAppo", { data: navbar, appodata: appodata })
  }
  catch (err) { console.log(err) }

})




//here we hardcode and send the navbar data to database because here no need any userinteraction to nav bar so we hard code it
//run below function for once to push data
// async function run(){
//   try{
//     let navbar=new document({
//       companyname:"xyzCompany",
//   logo:"/images/logo.jpj",
//   link:[{
//     label:"Home",
//     url:"/"
//   },
//         {
//           label:"Services",
//           url:"/services"
//         },
//         {
//           label:"Achievements",
//           url:"/achievements"
//         },
//         {
//           label:"Make-Appointment",
//           url:"/make-appointments"
//         },
//         {
//           label:"ContactUs",
//           url:"/contactus"
//         }
//        ]
//     })
//     await navbar.save()
//    console.log(navbar)
//   }
//   catch(e){
//      console.log(e.message)
//    }
// }
// run()


//this is for send sliderdata to db no need to user intercation so hard code it

// async function run(){
//   try{
//     let sliderdata=new sliderdoc(
//     //   {
//     //   title:"our shop is open",
//     //   subtitle:"Looking good isn't self-importance, it's self-respect.",
//     //   url:"/images/pic3.jpg"
//     // }

//      )
//    // await sliderdata.save()
// //       let sliderData = await sliderdoc.find();
// // console.log(sliderData);this two lines is for checking


//   }
//   catch(e){
//      console.log(e.message)
//    }
// }
// run()
// {
//   title:"Comfortable,Relaxing,Invigorating. ",
//     subtitle:"Come take your rightful place on our throne",
//     url:"/images/pic2.jpg"    
//  }
//  {
//  title:"we are witing for angels ",
//  subtitle:"Invest in your hair, it's the crown you never take off.",
//    url:"/images/pic.jpg"   
// }above function send this two object also one by one for once it can save only one object


//push service data
// async function run(){
//   try{
//     let servicedata=new services({
//       url:"/images/service6.jpg",
//       title:"Bridal packages",
//       subtitle:" Provide special packages for brides-to-be that include hair and makeup services for their wedding day."   
//     })
//    await servicedata.save()
// //       let sliderData = await sliderdoc.find();
// // console.log(sliderData);this two lines is for checking
//     }
//   catch(e){
//      console.log(e.message)
//    }
// }
// run()
// above i insert 6 different service data see in database in service tabel
// push achievement data
// async function run(){
//   try{
//     let achdata=new achdoc({
//       url:"/images/ach6.jpg",
//       title:"Trendy Haircuts for the Cool Kids",
//       subtitle:"A child's hair is a reflection of their innocence and joy."
//     })
//    await achdata.save()
// //       let sliderData = await sliderdoc.find();
// // console.log(sliderData);this two lines is for checking
//     }
//   catch(e){
//      console.log(e.message)
//    }
// }
// run()











module.exports = router