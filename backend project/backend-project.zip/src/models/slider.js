let mongoose=require("mongoose")

let sliderschema=new mongoose.Schema({
    title:String,
   subtitle:String,
  url:String,
})


module.exports=mongoose.model("sliders",sliderschema)