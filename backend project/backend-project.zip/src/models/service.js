let mongoose=require("mongoose")

let sliderschema=new mongoose.Schema({
    url:String,
    title:String,
    subtitle:String   
})


module.exports=mongoose.model("service",sliderschema)