 let mongoose=require("mongoose")

let schema=new mongoose.Schema({
  companyname:String,
  logo:String,
  link:[{
    label:String,
    url:String,
  }]//here ther is multiple links hence we put in array
})



















module.exports=mongoose.model("navbars",schema)