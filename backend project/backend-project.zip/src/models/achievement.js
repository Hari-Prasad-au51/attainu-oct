let mongoose=require("mongoose")

let achschema=new mongoose.Schema({
    url:String,
    title:String,
    subtitle:String   
})


module.exports=mongoose.model("achievements",achschema)