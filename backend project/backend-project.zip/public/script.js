
// function func() {
//   const datetag = document.getElementById("datepicker");
//    // console.log(datetag.value)
//   let date=datetag.value
  
//    window.location.href = '/make-appointments?name=' + date;
// }

   
