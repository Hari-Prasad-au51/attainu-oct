const express = require("express")
const app = express()
const cors = require('cors');
app.use(cors());

let mongoose = require("mongoose")

const bodyParser = require('body-parser');

const username = process.env['MONGO_USERNAME']
const password = process.env['MONGO_PASSWORD']
const port = process.env['port']

let db = mongoose.connect(`mongodb+srv://${username}:${password}@cluster0.mor8vos.mongodb.net/finalprtdb?retryWrites=true&w=majority`, { useNewUrlParser: true, useUnifiedTopology: true }).then(() => { console.log("db connected sucessfully") }).catch((err) => { console.log(`err`, err.message) })


app.use(express.static(__dirname + "/public"))

app.use(express.json({limit:"50mb"}))
app.use(bodyParser.urlencoded({ extended: true,limit:"50mb" }));



let routersuser = require("./src/routers/user")
app.use("", routersuser)//we not assign endpont default it take first "/" is end point






app.listen(port, () => { console.log("app run on port 3001") })