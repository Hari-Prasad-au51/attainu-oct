let express=require("express")
const fileUpload = require('express-fileupload');






let {register,login}=require("../controllers/auth")
let sell=require("../controllers/addsell")
let getprod=require("../controllers/getproduct")
let Myadds=require("../controllers/myadd")
let Deleteadd =require("../controllers/deleteadd")
let Addcart =require("../controllers/addcart")
let MyFavourites =require("../controllers/myfavourite")
let DeleteMyFavourite=require("../controllers/deleteMyfavourite")
let {Sendotp,ChangePassword} =require("../controllers/forgetpassword")


let authentication =require("../middlewears/authentication")



let router=express()
router.use(fileUpload());

router.get("/",(req,res)=>{
  res.send("server")
})

router.post("/register",register)

router.post("/login",login)

router.post("/addsell",authentication,sell)

 router.get("/allprod",getprod)

router.get("/myadds/:id",authentication, Myadds);

router.delete("/deleteadd/:id",authentication, Deleteadd);

router.post("/addcart",authentication,Addcart)

router.get("/myfavourite/:id",authentication, MyFavourites);

router.delete("/deleteMyfavourite/:id",authentication, DeleteMyFavourite);


router.post("/sendotp",Sendotp)

router.post("/changepassword",ChangePassword)







module.exports= router