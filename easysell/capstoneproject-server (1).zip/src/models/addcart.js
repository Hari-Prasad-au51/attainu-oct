

const mongoose = require("mongoose");

// register user schema
const Cart = new mongoose.Schema({

  current_user_id: String,
  product_id:String
});



module.exports = mongoose.model("Cart", Cart);